var imgs = await simple.prepareMessage('0@c.us', thubb, image, { thumbnail: thubb })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = simple.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "62815143205943",
                        "title": `ALL MENU`,
                        "description": menu,
                        "footerText": `© z8Bot`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `${tampilUcapan}`,
                        "url": "Love You All >_<\nhttps://youtube.com/channel/UCYDZpsK1w7hWYInmyZowrUA"
                    },
                    "businessOwnerJid": "62815143205943@s.whatsapp.net",
                }
            }, { quoted: mek, mimetype: 'image/jpeg' })
            simple.relayWAMessage(ctlg)